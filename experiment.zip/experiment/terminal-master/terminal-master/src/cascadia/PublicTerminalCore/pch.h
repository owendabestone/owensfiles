// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.

#include <LibraryIncludes.h>
