// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.

#pragma once

#include <cpprest/details/web_utilities.h>

const utility::string_t AzureClientID = U("0");
